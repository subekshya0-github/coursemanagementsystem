-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 11, 2024 at 09:35 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `course_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE `activity` (
  `ID` int(11) NOT NULL,
  `Activities` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`ID`, `Activities`) VALUES
(31, 'logged in by:\'Admin\' ,email: \'Sube1@gmail.com\' at \'2024-02-10 20:18:16\''),
(32, 'logged in by:\'Teacher\' ,email: \'jenny1@gmail.com\' at \'2024-02-10 20:23:18\''),
(33, 'logged in by:\'Teacher\' ,email: \'jenny1@gmail.com\' at \'2024-02-10 20:27:43\''),
(34, 'logged in by:\'Student\' ,email: \'Samjhana1@gmail.com\' at \'2024-02-10 20:29:32\''),
(35, 'logged in by:\'Admin\' ,email: \'sube1@gmail.com\' at \'2024-02-11 23:51:17\''),
(36, 'logged in by:\'Teacher\' ,email: \'jenny1@gmail.com \' at \'2024-02-12 00:09:48\''),
(37, 'logged in by:\'Teacher\' ,email: \'jenny1@gmail.com \' at \'2024-02-12 00:09:53\''),
(38, 'logged in by:\'Teacher\' ,email: \'jenny1@gmail.com \' at \'2024-02-12 00:10:34\''),
(39, 'logged in by:\'Student\' ,email: \'samjhana1@gmail.com\' at \'2024-02-12 00:19:37\''),
(40, 'logged in by:\'Admin\' ,email: \'sube1@gmail.com \' at \'2024-02-12 00:41:26\'');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ID` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `Password` varchar(50) DEFAULT NULL,
  `User` varchar(50) DEFAULT NULL,
  `Phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ID`, `FirstName`, `LastName`, `Email`, `Password`, `User`, `Phone`) VALUES
(3, 'Sube', 'Dhamala', 'sube1@gmail.com', 'sube1', 'Admin', '9845367889');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `ID` int(11) NOT NULL,
  `Course_Name` varchar(100) DEFAULT NULL,
  `Seats` varchar(1000) DEFAULT NULL,
  `Batch` varchar(1000) DEFAULT NULL,
  `No_of_Years` varchar(120) DEFAULT NULL,
  `Module` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`ID`, `Course_Name`, `Seats`, `Batch`, `No_of_Years`, `Module`) VALUES
(6, 'BIT', '150', '2023', '1', '4CS015');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `ID` int(11) NOT NULL,
  `Full_Name` varchar(100) DEFAULT NULL,
  `Email` varchar(1000) DEFAULT NULL,
  `Module` varchar(1000) DEFAULT NULL,
  `Subject` varchar(120) DEFAULT NULL,
  `Marks` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`ID`, `Full_Name`, `Email`, `Module`, `Subject`, `Marks`) VALUES
(2, 'samjhana', 'samjhana1@gmail.com', 'nmc', 'BIT', '90');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `ID` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `Password` varchar(50) DEFAULT NULL,
  `User` varchar(50) DEFAULT NULL,
  `Phone` varchar(120) DEFAULT NULL,
  `Course` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`ID`, `FirstName`, `LastName`, `Email`, `Password`, `User`, `Phone`, `Course`) VALUES
(11, 'Samjhana', 'Dhamala', 'samjhana1@gmail.com', 'samjhana1', 'Student', '9860799133', 'BIT');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `ID` int(11) NOT NULL,
  `First_Name` varchar(100) DEFAULT NULL,
  `Last_Name` varchar(1000) DEFAULT NULL,
  `Email` varchar(1000) DEFAULT NULL,
  `Password` varchar(1200) DEFAULT NULL,
  `User` varchar(50) DEFAULT NULL,
  `Phone` varchar(120) DEFAULT NULL,
  `Course` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`ID`, `First_Name`, `Last_Name`, `Email`, `Password`, `User`, `Phone`, `Course`) VALUES
(10, 'Jenny', 'Rajak', 'jenny1@gmail.com', 'jenny1', 'Teacher', '9874563214', 'BIT'),
(11, 'Jenny', 'Rajak', 'jenny1@gmail.com', 'jenny1', 'Teacher', '9874563214', 'BIT');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity`
--
ALTER TABLE `activity`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
